﻿Public Class Control
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form1.WebBrowser1.Navigate(TextBox1.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.WebBrowser1.GoForward()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.WebBrowser1.GoBack()
    End Sub

    Private Sub GoogleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GoogleToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("google.com")
        Form1.Text = "Window Browser - Google Pre-Site Selection"
    End Sub

    Private Sub BingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BingToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("bing.com")
        Form1.Text = "Window Browser - Bing Pre-Site Selection"
    End Sub

    Private Sub YahooToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles YahooToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("yahoo.com")
        Form1.Text = "Window Browser - Yahoo! Pre-Site Selection"
    End Sub

    Private Sub EcosiaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EcosiaToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("Ecosia.org")
        Form1.Text = "Window Browser - Ecosia Pre-Site Selection"
    End Sub
End Class