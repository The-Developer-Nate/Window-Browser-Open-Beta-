﻿Public Class App_Launcher
    Private Sub OtherToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OtherToolStripMenuItem.Click
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.Filter = "Applications (*.exe)|*.exe|All Files (*.*)|*.*"
        OpenFileDialog1.CheckFileExists = True
        OpenFileDialog1.CheckPathExists = True
        System.Diagnostics.Process.Start(OpenFileDialog1.FileName)
    End Sub

    Private Sub NotepadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NotepadToolStripMenuItem.Click
        System.Diagnostics.Process.Start("Notepad")
    End Sub
End Class