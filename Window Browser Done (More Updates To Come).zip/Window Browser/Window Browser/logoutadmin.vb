﻿Imports System.Windows.Forms

Public Class logoutadmin

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
        Admin.Close()
        MessageBox.Show("You Logged Out Of Admin Mode.")
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
        MessageBox.Show("You Canceled Logging Out Of Admin Mode!")
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
        Admin.Close()
        MessageBox.Show("You Logged Out Of Admin Mode.")
    End Sub

    Private Sub CancelLogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CancelLogoutToolStripMenuItem.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
        MessageBox.Show("You Canceled Logging Out Of Admin Mode!")
    End Sub
End Class
