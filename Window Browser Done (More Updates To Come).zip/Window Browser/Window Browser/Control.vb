﻿Public Class Control
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form1.WebBrowser1.Navigate(TextBox1.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.WebBrowser1.GoForward()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.WebBrowser1.GoBack()
    End Sub

    Private Sub GoogleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GoogleToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("google.com")
        Form1.Text = "Window Browser - Google Pre-Site Selection"
    End Sub

    Private Sub BingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BingToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("bing.com")
        Form1.Text = "Window Browser - Bing Pre-Site Selection"
    End Sub

    Private Sub YahooToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles YahooToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("yahoo.com")
        Form1.Text = "Window Browser - Yahoo! Pre-Site Selection"
    End Sub

    Private Sub EcosiaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EcosiaToolStripMenuItem.Click
        Form1.WebBrowser1.Navigate("Ecosia.org")
        Form1.Text = "Window Browser - Ecosia Pre-Site Selection"
    End Sub

    Private Sub ChangeFormatToolStripMenuItem_Click(sender As Object, e As EventArgs)
        FontDialog1.ShowDialog()
    End Sub

    Private Sub TheDeveloperNateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TheDeveloperNateToolStripMenuItem.Click
        Github_Social.Show()
    End Sub

    Private Sub NathanCrazymanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NathanCrazymanToolStripMenuItem.Click
        Process.Start("https://www.youtube.com/channel/UCnRmB_bOk18YTo4H1YERrEg")
    End Sub

    Private Sub RainbowPlaysToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles RainbowPlaysToolStripMenuItem1.Click
        Process.Start("https://www.youtube.com/channel/UCJ_-0ysXUfiBBgE2N9_yi1w")
    End Sub

    Private Sub MarkToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MarkToolStripMenuItem.Click
        Process.Start("Mailto:marklee98@gmail.com?body=Hi_Mark_I_Got_Sent_Here_Because_Of_Window_Browser_Application")
    End Sub
End Class