﻿Public Class Admin
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If TextBox1.Text = "web.reset" Then
            Form1.WebBrowser1.Navigate("About:Blank")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        logoutadmin.Show()
    End Sub
End Class